Planq Brand Assets
